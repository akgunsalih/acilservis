<h2>Hello</h2> <br><br>
You have got an email from : {{ $first_name }} <br><br>

User details: <br><br>

Name: {{ $first_name }} {{ $last_name }} <br>
Email: {{ $email }} <br>
Phone: {{ $phone_no }} <br>
Subject: {{ $subject }} <br>
Message: {{ $user_message }} <br><br>

Thanks