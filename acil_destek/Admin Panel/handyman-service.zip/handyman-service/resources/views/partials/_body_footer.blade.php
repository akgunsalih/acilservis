<footer class="iq-footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-6 ">
                <span class="mr-1">
                {{ __('messages.copyright') }} {{ date('Y') }} © <a href="#" class="">{{ env('APP_NAME') }}</a>
                   {{ __('messages.all_rights_reserved') }}
                </span>
            </div>
        </div>
    </div>
</footer>