<link rel="shortcut icon" class="site_favicon_preview" href="{{ getSingleMedia(settingSession('get'),'site_favicon',null) }}" />
<link rel='stylesheet' href="{{ asset('vendor/fullcalendar/core/main.css')}}" />
<link rel='stylesheet' href="{{ asset('vendor/fullcalendar/daygrid/main.css')}}" />
<link rel='stylesheet' href="{{ asset('vendor/fullcalendar/timegrid/main.css')}}" />
<link rel='stylesheet' href="{{ asset('vendor/fullcalendar/list/main.css')}}" />
<link rel="stylesheet" href="{{ asset('css/backend-plugin.min.css')}}">
<link rel="stylesheet" href="{{ asset('css/backend.css?v=1.0.0')}}">
<link rel="stylesheet" href="{{ asset('vendor/@fortawesome/fontawesome-free/css/all.min.css')}}">
<link rel="stylesheet" href="{{ asset('vendor/line-awesome/dist/line-awesome/css/line-awesome.min.css')}}">
<link rel="stylesheet" href="{{ asset('vendor/remixicon/fonts/remixicon.css')}}">
<link rel="stylesheet" href="{{ asset('vendor/confirmJs/jquery-confirm.css')}}">
<!-- <link rel="stylesheet" href="{{ asset('vendor/select2/css/select2.min.css')}}"> -->
<link rel="stylesheet" href="{{ asset('css/themes/select2.min.css')}}">
<link rel="stylesheet" href="{{ asset('vendor/magnific-popup/magnific-popup.css') }}">
<link rel="stylesheet" href="{{ asset('css/custom.css')}}">
