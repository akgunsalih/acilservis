<?php 
return [
  'reset' => '¡Tu contraseña ha sido restablecida!',
  'sent' => '¡Hemos enviado el enlace de restablecimiento de su contraseña!',
  'throttled' => 'Por favor espere antes de volver a intentarlo.',
  'token' => 'Este token de restablecimiento de contraseña no es válido.',
  'user' => 'No podemos encontrar un usuario con esa dirección de correo electrónico.',
];