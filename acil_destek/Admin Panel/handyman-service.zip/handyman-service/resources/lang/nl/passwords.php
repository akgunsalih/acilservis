<?php 
return [
  'reset' => 'Jouw wachtwoord is gereset!',
  'sent' => 'We hebben uw wachtwoord reset-link gemaild!',
  'throttled' => 'Wacht alstublieft voordat u opnieuw probeert.',
  'token' => 'Dit wachtwoord reset-token is ongeldig.',
  'user' => 'We kunnen een gebruiker niet vinden met dat e-mailadres.',
];