class AboutModel {
  String? title;
  String? image;

  AboutModel({this.title, this.image});
}
